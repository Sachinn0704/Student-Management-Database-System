-- ============================================================================
-- SQL DATA ANALYSIS INTERNSHIP - TASK 1
-- Student Management Database
-- ============================================================================

-- ============================================================================
-- SECTION 1: DATABASE SETUP
-- ============================================================================

-- Step 1: Create the database called StudentManagement
-- This creates a new database container for our student data
CREATE DATABASE StudentManagement;

-- Step 2: Switch to using the StudentManagement database
-- All subsequent operations will be performed on this database
USE StudentManagement;

-- Step 3: Create the Students table with specified fields
-- This table will store all student information and their scores
CREATE TABLE Students (
    StudentID INT PRIMARY KEY AUTO_INCREMENT,  -- Unique identifier, automatically increments
    Name VARCHAR(50),                          -- Student's full name (max 50 characters)
    Gender CHAR(1),                            -- 'M' for Male, 'F' for Female
    Age INT,                                   -- Student's age in years
    Grade VARCHAR(2),                          -- Grade level (e.g., 'A', 'B', 'C')
    MathScore INT,                             -- Score in Mathematics (0-100)
    ScienceScore INT,                          -- Score in Science (0-100)
    EnglishScore INT                           -- Score in English (0-100)
);

-- ============================================================================
-- SECTION 2: INSERT DATA (At least 10 records with variety)
-- ============================================================================

-- Inserting diverse student records with different grades, genders, ages, and scores
-- This data set includes variety in performance levels and demographics

INSERT INTO Students (Name, Gender, Age, Grade, MathScore, ScienceScore, EnglishScore) VALUES
('Rajesh Kumar', 'M', 16, 'A', 92, 88, 85),      -- High performer in Math
('Priya Sharma', 'F', 15, 'A', 95, 90, 92),      -- Top overall performer
('Amit Patel', 'M', 17, 'B', 78, 82, 75),        -- Average performer
('Sneha Reddy', 'F', 16, 'A', 88, 85, 90),       -- Strong in English
('Vikram Singh', 'M', 15, 'C', 65, 70, 68),      -- Below average performer
('Anjali Verma', 'F', 16, 'B', 82, 79, 84),      -- Consistent performer
('Rohit Gupta', 'M', 17, 'A', 90, 87, 88),       -- High performer
('Kavya Nair', 'F', 15, 'B', 75, 78, 80),        -- Moderate performer
('Arjun Mehta', 'M', 16, 'C', 60, 65, 62),       -- Low performer
('Divya Iyer', 'F', 17, 'A', 85, 91, 87),        -- Strong in Science
('Karan Desai', 'M', 15, 'B', 81, 76, 79),       -- Average performer
('Neha Joshi', 'F', 16, 'A', 93, 89, 91),        -- High performer
('Siddharth Roy', 'M', 17, 'C', 70, 68, 72),     -- Below average performer
('Pooja Malhotra', 'F', 15, 'B', 84, 83, 86);    -- Good all-rounder

-- ============================================================================
-- SECTION 3: SQL QUERIES TO PERFORM
-- ============================================================================

-- ----------------------------------------------------------------------------
-- QUERY 1: Show all student details
-- Purpose: Display complete information about all students in the database
-- ----------------------------------------------------------------------------
SELECT * FROM Students;

-- Expected Result: All 14 student records with all columns displayed
-- This gives us a complete overview of the entire dataset


-- ----------------------------------------------------------------------------
-- QUERY 2: Average score in each subject
-- Purpose: Calculate the mean score for Math, Science, and English across all students
-- This helps identify which subjects students perform best/worst in overall
-- ----------------------------------------------------------------------------
SELECT 
    AVG(MathScore) AS AvgMathScore,          -- Average of all Math scores
    AVG(ScienceScore) AS AvgScienceScore,    -- Average of all Science scores
    AVG(EnglishScore) AS AvgEnglishScore     -- Average of all English scores
FROM Students;

-- Expected Result: Three average values showing overall performance by subject
-- Example: AvgMathScore: 81.29, AvgScienceScore: 80.07, AvgEnglishScore: 80.64


-- ----------------------------------------------------------------------------
-- QUERY 3: Top performer (highest total score)
-- Purpose: Identify the student with the best overall academic performance
-- We calculate total score and sort to find the highest
-- ----------------------------------------------------------------------------
SELECT 
    StudentID,                                                    -- Student's unique ID
    Name,                                                        -- Student's name
    (MathScore + ScienceScore + EnglishScore) AS TotalScore     -- Sum of all three subjects
FROM Students
ORDER BY TotalScore DESC                                        -- Sort in descending order
LIMIT 1;                                                        -- Take only the top student

-- Expected Result: Priya Sharma with TotalScore of 277 (95+90+92)
-- This identifies our highest achieving student overall


-- ----------------------------------------------------------------------------
-- QUERY 4: Count students per grade
-- Purpose: See the distribution of students across different grade levels
-- This helps understand how students are categorized by performance
-- ----------------------------------------------------------------------------
SELECT 
    Grade,                    -- The grade level (A, B, or C)
    COUNT(*) AS StudentCount  -- Number of students in each grade
FROM Students
GROUP BY Grade               -- Group all students by their grade
ORDER BY Grade;              -- Sort alphabetically by grade

-- Expected Result: 
-- Grade A: 6 students, Grade B: 5 students, Grade C: 3 students
-- Shows that most students are in higher grades


-- ----------------------------------------------------------------------------
-- QUERY 5: Average score by gender
-- Purpose: Compare academic performance between male and female students
-- This helps identify if there are any gender-based performance differences
-- ----------------------------------------------------------------------------
SELECT 
    Gender,                                  -- Male or Female
    AVG(MathScore) AS AvgMath,              -- Average Math score by gender
    AVG(ScienceScore) AS AvgScience,        -- Average Science score by gender
    AVG(EnglishScore) AS AvgEnglish,        -- Average English score by gender
    AVG(MathScore + ScienceScore + EnglishScore) AS AvgTotal  -- Average total score
FROM Students
GROUP BY Gender;                            -- Separate calculations for M and F

-- Expected Result: Shows comparative performance between genders
-- Example: Female students might have slightly higher average scores overall


-- ----------------------------------------------------------------------------
-- QUERY 6: Students with Math score > 80
-- Purpose: Filter and display students who excel in Mathematics
-- This identifies students with strong mathematical abilities
-- ----------------------------------------------------------------------------
SELECT 
    StudentID,
    Name,
    Gender,
    Age,
    Grade,
    MathScore
FROM Students
WHERE MathScore > 80        -- Condition: Only students scoring above 80 in Math
ORDER BY MathScore DESC;    -- Sort from highest to lowest Math score

-- Expected Result: 8 students with Math scores above 80
-- Includes students like Priya Sharma (95), Neha Joshi (93), Rajesh Kumar (92), etc.


-- ----------------------------------------------------------------------------
-- QUERY 7: Update a student's grade
-- Purpose: Demonstrate how to modify existing data (UPDATE operation)
-- We'll promote Vikram Singh from Grade C to Grade B based on improvement
-- ----------------------------------------------------------------------------

-- First, let's see Vikram Singh's current grade
SELECT Name, Grade FROM Students WHERE Name = 'Vikram Singh';

-- Update Vikram Singh's grade from C to B
-- This simulates a scenario where a student's performance improved
UPDATE Students
SET Grade = 'B'                    -- New grade value
WHERE Name = 'Vikram Singh';       -- Condition: Only update this specific student

-- Verify the update was successful
SELECT Name, Grade FROM Students WHERE Name = 'Vikram Singh';

-- Expected Result: Vikram Singh's grade changes from 'C' to 'B'


-- ============================================================================
-- ADDITIONAL ANALYTICAL QUERIES (BONUS)
-- ============================================================================

-- ----------------------------------------------------------------------------
-- BONUS QUERY 1: Students with total score above average
-- Purpose: Identify above-average performers
-- ----------------------------------------------------------------------------
SELECT 
    Name,
    (MathScore + ScienceScore + EnglishScore) AS TotalScore
FROM Students
WHERE (MathScore + ScienceScore + EnglishScore) > (
    SELECT AVG(MathScore + ScienceScore + EnglishScore) FROM Students
)
ORDER BY TotalScore DESC;


-- ----------------------------------------------------------------------------
-- BONUS QUERY 2: Subject-wise top scorers
-- Purpose: Find the highest scorer in each subject
-- ----------------------------------------------------------------------------
-- Top scorer in Math
SELECT Name, MathScore FROM Students WHERE MathScore = (SELECT MAX(MathScore) FROM Students);

-- Top scorer in Science
SELECT Name, ScienceScore FROM Students WHERE ScienceScore = (SELECT MAX(ScienceScore) FROM Students);

-- Top scorer in English
SELECT Name, EnglishScore FROM Students WHERE EnglishScore = (SELECT MAX(EnglishScore) FROM Students);


-- ----------------------------------------------------------------------------
-- BONUS QUERY 3: Performance summary by grade
-- Purpose: Compare average performance across different grades
-- ----------------------------------------------------------------------------
SELECT 
    Grade,
    COUNT(*) AS TotalStudents,
    AVG(MathScore) AS AvgMath,
    AVG(ScienceScore) AS AvgScience,
    AVG(EnglishScore) AS AvgEnglish,
    AVG(MathScore + ScienceScore + EnglishScore) AS AvgTotalScore
FROM Students
GROUP BY Grade
ORDER BY AvgTotalScore DESC;

-- ============================================================================
-- END OF SCRIPT
-- ============================================================================
